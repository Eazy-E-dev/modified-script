ESX = nil

TriggerEvent('esx:getSharedObject', function(obj)
	ESX = obj
end)

ESX.RegisterUsableItem('beer', function(source)

	local xPlayer = ESX.GetPlayerFromId(source)

	xPlayer.removeInventoryItem('beer', 1)

	TriggerClientEvent('esx_status:add', source, 'drunk', 25000)
	TriggerClientEvent('esx_optionalneeds:onDrink', source)
	TriggerClientEvent('mythic_notify:client:SendAlert', source, { type = 'success', text = 'You have drinken some Beer!', style = { ['background-color'] = '#00DCFF', ['color'] = '#000000' } })

end)

ESX.RegisterUsableItem('vodka', function(source)
	
	local xPlayer = ESX.GetPlayerFromId(source)

	xPlayer.removeInventoryItem('vodka', 1)

	TriggerClientEvent('esx_status:add', source, 'drunk', 25000)
	TriggerClientEvent('esx_optionalneeds:onDrink', source)
	TriggerClientEvent('mythic_notify:client:SendAlert', source, { type = 'success', text = 'You have drinken some Vodka!', style = { ['background-color'] = '#00DCFF', ['color'] = '#000000' } })

end)

ESX.RegisterUsableItem('tequila', function(source)

	local xPlayer = ESX.GetPlayerFromId(source)

	xPlayer.removeInventoryItem('tequila', 1)

	TriggerClientEvent('esx_status:add', source, 'drunk', 25000)
	TriggerClientEvent('esx_optionalneeds:onDrink', source)
	TriggerClientEvent('mythic_notify:client:SendAlert', source, { type = 'success', text = 'You have drinken some Tequila!', style = { ['background-color'] = '#00DCFF', ['color'] = '#000000' } })

end)

ESX.RegisterUsableItem('rum', function(source)

	local xPlayer = ESX.GetPlayerFromId(source)

	xPlayer.removeInventoryItem('rum', 1)

	TriggerClientEvent('esx_status:add', source, 'drunk', 25000)
	TriggerClientEvent('esx_optionalneeds:onDrink', source)
	TriggerClientEvent('mythic_notify:client:SendAlert', source, { type = 'success', text = 'You have drinken some Rum!', style = { ['background-color'] = '#00DCFF', ['color'] = '#000000' } })

end)

ESX.RegisterUsableItem('lean', function(source)

	local xPlayer = ESX.GetPlayerFromId(source)
        
	xPlayer.removeInventoryItem('lean', 1)
	
    TriggerClientEvent('esx_status:add', source, 'drunk', 25000)
	TriggerClientEvent('esx_optionalneeds:onDrink2', source)
	TriggerClientEvent('mythic_notify:client:SendAlert', source, { type = 'success', text = 'You have sipped some Lean!', style = { ['background-color'] = '#00DCFF', ['color'] = '#000000' } })

end)

ESX.RegisterUsableItem('wine', function(source)

	local xPlayer = ESX.GetPlayerFromId(source)

	xPlayer.removeInventoryItem('wine', 1)

	TriggerClientEvent('esx_status:add', source, 'drunk', 25000)
	TriggerClientEvent('esx_optionalneeds:onDrink', source)
	TriggerClientEvent('mythic_notify:client:SendAlert', source, { type = 'success', text = 'You have drinken some Wine!', style = { ['background-color'] = '#00DCFF', ['color'] = '#000000' } })

end)

ESX.RegisterUsableItem('martini', function(source)

	local xPlayer = ESX.GetPlayerFromId(source)

	xPlayer.removeInventoryItem('martini', 1)

	TriggerClientEvent('esx_status:add', source, 'drunk', 25000)
	TriggerClientEvent('esx_optionalneeds:onDrink', source)
	TriggerClientEvent('mythic_notify:client:SendAlert', source, { type = 'success', text = 'You have sipped some Martini!', style = { ['background-color'] = '#00DCFF', ['color'] = '#000000' } })

end)
