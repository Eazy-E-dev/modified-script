Locales['en'] = {
	
	['used_beer'] = 'you used 1x ~y~Beer~s~',
	['used_vodka'] = 'you used 1x ~y~Vodka~s~',
	['used_tequila'] = 'you used 1x ~y~Tequila~s~',
	['used_rum'] = 'you used 1x ~y~Rum~s~',

}
