Locales['es'] = {
    
    ['used_beer'] = 'Has usado 1x ~y~Cerveza~s~',

}
