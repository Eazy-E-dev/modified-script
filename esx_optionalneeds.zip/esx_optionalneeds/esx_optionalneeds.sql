USE `es_extended`;

INSERT INTO `items` (`name`, `label`, `weight`) VALUES
	('beer', 'Beer', 1),
	('vodka', 'Vodka', 1),
	('tequila', 'Tequila', 1),
	('rum', 'Rum', 1),
	('lean', 'Lean', 1),
	('wine', 'Wine', 1),
	('martini', 'Martini', 1)
;

INSERT INTO `shops` (store, item, price) VALUES
	('RobsLiquor', 'vodka', 45),
	('RobsLiquor', 'beer', 25),
	('RobsLiquor', 'rum', 50),
	('RobsLiquor', 'tequila', 40),
	('RobsLiquor', 'wine', 40),
;
